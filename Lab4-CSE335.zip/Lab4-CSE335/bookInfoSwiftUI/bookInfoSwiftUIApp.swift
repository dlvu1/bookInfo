//
//  bookInfoSwiftUIApp.swift
//  bookInfoSwiftUI
//
//  Created by Duyen Vu on 2/13/24.
//

import SwiftUI

@main
struct personInfoSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
